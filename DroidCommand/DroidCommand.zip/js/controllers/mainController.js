﻿angular.module('driodCommand')
.controller('MainController', ['$scope', '$location', '$http', function ($scope, $location, $http) {    

    $scope.activeDroidIdx = 0;
    
    $scope.allDroid = {
        ID: 0,
        Name: 'All',
        Img: 'img/droid.PNG',
        Mode: 'N/A',
        Actions: [{ Name: "Sheila", Img: "img/find.PNG" }, { Name: "Left", Img: "img/left.PNG" }],
        Battery: 'N/A'
    };

    $scope.droidList = [
    {
        ID: 1,
        Name: 'Bruce',
        Img: 'img/droid.PNG',
        Mode: 'Autonomous',
        Actions: [{ Name: "Sheila", Img: "img/find.PNG" }, { Name: "Left", Img: "img/left.PNG" }],
        Battery: 10
    },
    {
        ID: 2,
        Name: 'John',
        Img: 'img/droid.PNG',
        Mode: 'Autonomous',
        Actions: [{ Name: "Sheila", Img: "img/find.PNG" }, { Name: "Left", Img: "img/left.PNG" }],
        Battery: 40
    },
    {
        ID: 3,
        Name: 'James',
        Img: 'img/droid.PNG',
        Mode: 'Autonomous',
        Actions: [{ Name: "Sheila", Img: "img/find.PNG" }, { Name: "Left", Img: "img/left.PNG" }],
        Battery: 60
    }];

    $scope.gamesList = [
        {
            ID: 1,
            Name: 'Command',
            Img: 'img/gameCommand.PNG'
        },
    {
        ID: 2,
        Name: 'Evolution',
        Img: 'img/gameEvolution.PNG'
    },
    {
        ID: 3,
        Name: 'Rogue',
        Img: 'img/gameRogue.PNG'
    },
    {
        ID: 4,
        Name: 'Spider',
        Img: 'img/gameSpider.PNG'
    }];

    $scope.profile =
        {
            UserName: 'Johan',
            Img: 'img/defaultProfile.jpg',
            Rank: 'Cadet',
            Score: '3250'
        }

    // Set the activeDroid
    $scope.activeDroid = $scope.droidList[$scope.activeDroidIdx];

    $scope.leftClickUp = function ()
    {
        if (typeof bluetoothSerial != 'undefined')
            bluetoothSerial.write("LEFT UP", function () { }, function () { });
        else
            alert('BT Magic here Left UP: ' + $scope.activeDroid.Name);
    };
    $scope.leftClickDown = function ()
    {
        if (typeof bluetoothSerial != 'undefined')
            bluetoothSerial.write("LEFT DOWN", function () { }, function () { });
        else
            alert('BT Magic here Left DOWN: ' + $scope.activeDroid.Name);
    };
    $scope.rightClickUp = function () {
        if (typeof bluetoothSerial != 'undefined')
            bluetoothSerial.write("RIGHT UP", function () { }, function () { });
        else
            alert('BT Magic here Right UP: ' + $scope.activeDroid.Name);
    };
    $scope.rightClickDown = function () {
        if (typeof bluetoothSerial != 'undefined')
            bluetoothSerial.write("RIGHT DOWN", function () { }, function () { });
        else
            alert('BT Magic here Right DOWN: ' + $scope.activeDroid.Name);
    };

    $scope.changeDroid = function () {
        // $scope.$apply();
        if ($scope.activeDroidIdx < $scope.droidList.length - 1)
            $scope.activeDroidIdx++;
        else
            $scope.activeDroidIdx = 0;

        $scope.activeDroid = $scope.droidList[$scope.activeDroidIdx];        
    };

    $scope.toggleAllDroid = function () {
        if ($scope.activeDroid.ID != 0)
        {
            $scope.activeDroid = $scope.allDroid;
        } else
            $scope.activeDroid = $scope.droidList[$scope.activeDroidIdx];
    };

    $scope.showSettings = function () {
        $location.path('/bluetoothlist');
    };
    }]);