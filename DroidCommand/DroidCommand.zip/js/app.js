﻿angular.module('driodCommand', ['ngRoute']).
config(['$provide', '$routeProvider', function ($provide, $routeProvider) {
    $routeProvider
        .when('/', {
            templateUrl: 'views/main.html'
        }).when('/bluetoothlist', {
            templateUrl: 'views/bluetoothSelection.html'
        });
}]);